Here's a list of the libraries required for the modified code:

OpenCV: Used for video capturing and processing.

Install with pip: pip install opencv-python
Supervision: Used for annotation.

Install with pip: pip install supervision
Ultralytics: Used for the YOLO model.

Install with pip: pip install ultralytics
Make sure to install these libraries before running the code.
