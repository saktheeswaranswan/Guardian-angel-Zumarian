# yolo-traffic-ramaswamy-2.0-yolo-rama-swamy
Artificial intelligence Traffic Ramaswamy 2.0 yolo version legace of traffic rama swamy or yolo rama swamy


a person so courageous to fight against all evil in the society and this is  Artificial intelligence  coning traffic ramaswmay and 
this is just a proof of a concept to fight againt ever socil injustice aginst you iam giving this as a proof of a concept but  do not try this for any socil evil or against so please dont use for your personal evil pupose this is just a proof of the concept of survilance technique but if you you for any unwanted purpose through out india the github repostry owner isnot responsible for any dame in money loss of life or any property fight for truth and fall aas a seed this is seed of  traffic ramaswamy soo periyar ethical ai will be released thanthai peryiyar both are in common not only rama but also swamy
